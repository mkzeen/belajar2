# BaGen-Barcode-Generator

BaGen is barcode generator with code 128, BaGen build with PHP, 
you can develop it as you wish, feel free to use this code.
for mode tutorial, source code and application please visit www.hakkoblogs.com
